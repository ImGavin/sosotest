A chrome extension example:

Collect all http request and show them in the console.

sosotest-chrome-extension.pem  为crx打包的私钥文件